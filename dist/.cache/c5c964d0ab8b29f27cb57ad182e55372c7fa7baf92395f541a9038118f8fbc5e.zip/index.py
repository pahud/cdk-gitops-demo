def handler(event, context):
    return {"foo":"bar"}